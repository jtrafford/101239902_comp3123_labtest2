import logo from './logo.svg';
import './App.css';
import Weather from './Weather.js';

function App() {
  return (
    <div className="App">
      <Weather />
    </div>
  );
}

export default App;
